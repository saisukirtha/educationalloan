package com.educational_loan.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.educational_loan.demo.model.LoanApplicationModel;

public interface LoanApplicationRepo extends JpaRepository<LoanApplicationModel,Integer> {

}
