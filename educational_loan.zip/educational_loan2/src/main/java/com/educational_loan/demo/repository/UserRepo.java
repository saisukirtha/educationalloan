package com.educational_loan.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.educational_loan.demo.model.UserModel;

public interface UserRepo extends JpaRepository<UserModel,Integer> {

}
